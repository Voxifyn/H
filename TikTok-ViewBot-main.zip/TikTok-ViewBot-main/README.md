UPDATED !! (temporary fix) thanks to [@platipus9999](https://github.com/platipus9999)

`v2.py` has automatic captcha solver


&emsp;

<p align="center"> 
<img src="https://user-images.githubusercontent.com/98614666/218313368-e8b3613c-6639-4922-95ac-c23bbcdffdf1.png"></img>
</p>
<p align="center"> 
<img src="https://user-images.githubusercontent.com/98614666/218313369-31f5049c-0dd4-4eca-b323-cccc3436a418.png"></img>
</p>


How to run:
```
  1. Verify that you have pip and python installed => https://www.youtube.com/watch?v=dYfKJMPNMDw
  2. Run this command in cmd: pip install tls_client requests colorama pillow
  3. run the python file by double clicking on it or type: python viewbot.py
```

Advantages:
```
  1.  fast, easy
  2.  lightweight
  3.  Has dynamic views count running on TikTok API
  4.  mobile users can run it
```
